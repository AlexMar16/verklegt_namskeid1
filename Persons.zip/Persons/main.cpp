#include "consoleui.h"

using namespace std;

int main()
{
    consoleUI program;

    program.run();

    return 0;
}
