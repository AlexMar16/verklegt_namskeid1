
Directions on startup.

- Open Perons.pro with Qt (Persons.pro located in Persons folder).

- Try to build, if it fails follow the next step.

- Go to Project, on the left of the window, and change the building 
  directory to build-Persons-Desktop_Qt_5_7_0_clang_64bit-Debug.
  You can either browse the directory or copy it with the right path
  infront of it.

